fn main() {
    println!("bundled");
}
